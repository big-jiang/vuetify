<script>
const api = 'https://robot-1gk2vy2q8735f96a-1258099036.ap-shanghai.service.tcloudbase.com/robot';
var phone = '18258169721';
//const cms = 'https://robot-1gk2vy2q8735f96a-1258099036.tcloudbaseapp.com/tcb-cms/';
const cms = 'https://www.baidu.com';
export default {
    api,
    phone,
    cms
};
</script>
