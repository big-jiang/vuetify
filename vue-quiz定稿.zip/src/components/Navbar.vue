<template>
    <b-navbar id="navbar" class="custom-info" type="dark" sticky>
      <b-navbar-brand id="nav-logo" :to="{ name: 'home' }">答题初体验</b-navbar-brand>

      <b-navbar-nav class="ml-auto">
        <b-nav-item :to="{ name: 'home' }">重新答题</b-nav-item>
        <b-nav-item @click="loginOut()" target="_blank">关于</b-nav-item>
      </b-navbar-nav>
    </b-navbar>
</template>

<script>
export default {
  name: 'Navbar',
  methods:{
	loginOut(){
	alert("相关信息已清除，请重新登录！")
	this.$cookies.remove('login');
	this.$cookies.remove('form');
	this.$router.push({ name: 'login'});
	}
  }
}
</script>

<style scoped>

</style>

