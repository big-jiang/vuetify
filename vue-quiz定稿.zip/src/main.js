import Vue from 'vue'
import App from './App.vue'
import router from './router'
import BootstrapVue from 'bootstrap-vue'
import * as Tcb from 'vue-tcb'
import VueCookies from 'vue-cookies'
import { Checkbox } from 'ant-design-vue'
//import VConsole from 'vconsole'
import 'ant-design-vue/dist/antd.css'

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.config.productionTip = false

//const vConsole =new VConsole();

Vue.use(BootstrapVue)

Vue.use(Tcb,{env: 'env-web-16c0e3'})

Vue.use(VueCookies)

Vue.use(Checkbox)

// Vue.use(vConsole)

Vue.directive('title', {
  inserted: function (el) {
    document.title = el.dataset.title
  }
})

const state = { questions: [] }

const basic = { title:"111"}

const db = null

new Vue({
  router,
  data: {basic,state,db},
  render: h => h(App)
}).$mount('#app')
