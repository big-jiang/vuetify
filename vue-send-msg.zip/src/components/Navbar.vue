<template>
    <b-navbar id="navbar" class="custom-info" type="dark" sticky>
      <b-navbar-brand id="nav-logo" :to="{ name: 'sendmsg' }">{{title}}</b-navbar-brand>

      <b-navbar-nav class="ml-auto">
        <b-nav-item @click="loginOut()" target="_blank">退出</b-nav-item>
      </b-navbar-nav>
    </b-navbar>
</template>

<script>
export default {
  name: 'Navbar',
  data() {
    return {
    title:"钉钉云短信"
    };
  },
  created:function(){
    this.title = this.$cookies.get('form').name;
  },
  methods:{
	loginOut(){
	alert("相关信息已清除，请重新登录！")
	this.$cookies.remove('login');
	this.$cookies.remove('form');
	this.$router.push({ name: 'login'});
	}
  }
}
</script>

<style scoped>

</style>

