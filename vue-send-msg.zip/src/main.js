import Vue from 'vue'
import App from './App.vue'
import router from './router'
import BootstrapVue from 'bootstrap-vue'
import cloudbase from '@cloudbase/js-sdk'
import VueCookies from 'vue-cookies'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.config.productionTip = false

Vue.prototype['$cloud'] = cloudbase.init({env:'school-10be94'})

Vue.use(BootstrapVue)
Vue.use(VueCookies)

Vue.directive('title', {
  inserted: function (el) {
    document.title = el.dataset.title
  }
})

const state = { questions: [] }

const basic = { title:"111"}

var config = {
	appkey:'dinglwymead7j5al9t6k',
	appsecret:'R0siJgZSs1h4g6xDeHIJ7Gb03IkrSfBCoptXTE68CFbp6JtaiZAMqqu9ltemOgW0',
	corpId:'ding42404b8dd027ed3535c2f4657eb6378f',
	url:'http://172.18.1.170:8080/'
}

var name = '丁大将'

const db = null

const cloud = null
new Vue({
  router,
  data: {basic,state,db,cloud,config,name},
  render: h => h(App)
}).$mount('#app')
