<template>
<div>
<div class="d-flex flex-column">
  <div v-for="(grade,index) in school" :key="index">
    <b-button v-b-toggle="grade.grade" class="m-1" block>{{grade.grade}}</b-button>
    <b-collapse :id="grade.grade">
      <div class='d-flex justify-start'>
      <b-form-checkbox
        v-model="grade.selectedAll"
        @change="toggleAllGrade(index,grade)"
        >
      <div>{{grade.grade}} 总共{{grade.sum}}人{{ grade.selectedAll ? '全选' : '未全选' }}</div>
      </b-form-checkbox>
      </div>
      <div v-for="(cla,indexx) in grade.value" :key="indexx" class="pl-4 d-flex justify-start">
      <b-form-checkbox
          v-model="cla.selectedAll"
          @change="toggleAllClass(index,indexx,cla)"
        >
        {{grade.grade}}（{{cla._id.inclass-10}}）班 总共{{cla.sum}}人
      </b-form-checkbox>
      </div>
      </b-collapse>
  </div>
</div>

<div class="d-flex justify-content-center p-4">
<b-card
    img-src="https://picsum.photos/600/300/?image=25"
    img-alt="Image"
    img-top
    style="max-width: 30rem;"
    class=""
    > 
    <b-form-input
          id="input-2"
          v-model="sendmsg.title"
          required
          placeholder="请选择下列短信模板或自定义标题"
          class=""
        ></b-form-input>
    <b-form-textarea
      id="textarea"
      v-model="sendmsg.content"
      placeholder="发送内容详情"
      rows="3"
      max-rows="6"
    ></b-form-textarea>
</b-card>
</div>





<div class="p-4 mt-4">
<b-card-group deck>
  <b-card 
    :header="value.title" 
    class="text-center" 
    v-for="value in templates" 
    :key="value.title"
    @click="chooseTemplate(value.content,value.title)"
    >
    <b-card-text>{{value.content}}</b-card-text>
  </b-card>
</b-card-group>
</div>

<div class="fixed-bottom p-2" @click="sendMsg()"><b-button  v-if="sendmsg.content" block variant="">发送短信</b-button></div>
</div>
</template>

<script>
//import axios from 'axios'
export default {
  name: 'Upload',
  components: {
  },
  data() {
    return {
    school:[{grade:'一年级',value:[],selectedAll:true,sum:0,selected:0,phones:[]},{grade:'二年级',value:[],selectedAll:true,sum:0,selected:0,phones:[]}],
    flavours: ['1'],
    selected: [],
    allSelected: false,
    indeterminate: false,
    config:null,
    db:null,
    title:null,
    templates:null,
    classes:null,
    names:[],
    unnames:[],
    allphone:null,
    sendmsg:{
      content:null,
      phones:null,
      title:null
    }
    };
  },
  created:async function(){
  //console.log('form',this.$cookies.get('form'))
    await this.$cloud.auth({ persistence: "local" }).anonymousAuthProvider().signIn()
    this.db = this.$cloud.database();
    //this.config = this.$root.$data.config;
    this.getTemplates();
    this.getSchool();
    this.getGrade();
    if(this.$cookies.get('form')){
      //const form = this.$cookies.get('form')
      //this.getClass(form.grade,form.inclass);
      
    }else{
    //无数据,需要重新登录
    }
    //
  },
  mounted: function() {
  },
  methods: {
    async sendMsg(){
    //var phones = [];
    var submit = [];
    //console.log(this.school)
    this.school.forEach((grade)=>{
      if(grade.selectedAll){
        submit = submit.concat(grade.phones);
      }else{
        grade.value.forEach((cls)=>{
          if(cls.selectedAll){
            submit = submit.concat(cls.phones);
          }
        })
      }
      //console.log(submit)
    })
    
    if(submit&&this.sendmsg.content){
      this.sendmsg.phones = submit.toString();
      await this.$cloud.callFunction({
        name: "sendMsg",
        data: this.sendmsg
      }).then(res=>{
        //console.log(res);
        var msg = JSON.parse(res.result.split("&")[0].split("=")[1])
        if(msg == 0){
        this.$bvToast.toast(`发送成功`, {
          title:'Sendmsg',
          autoHideDelay: 2000,
          variant:'success',
          solid: true,
        })
        this.sendmsg.content = ''
        this.selected = [] 
        }else{
        if(msg==15){
          this.$bvToast.toast(`发送失败，请重新发送(15)`, {
          title:'Sendmsg',
          autoHideDelay: 2000,
          variant:'warning',
          solid: true,
        })
        }else{
          this.$bvToast.toast(`发送失败，请重试`, {
          title:'Sendmsg',
          autoHideDelay: 2000,
          variant:'danger',
          solid: true,
        })
        }
        }
      }).catch(()=>{
      this.$bvToast.toast(`发送失败，请重试(error)`, {
          title:'Sendmsg',
          autoHideDelay: 2000,
          variant:'danger',
          solid: true,
        })
      })
      
    }else{
      //信息不全
      console.log('发送信息不全')
    }
      
    },
    async getTemplates(){
      await this.db.collection('templates').get()
      .then(res=>{this.templates = res.data})
      .catch(console.error)
    },
    async getGrade(){
      const $ = this.db.command.aggregate
      await this.db.collection('students').aggregate()
      .group({
        _id: {inschool:'$inschool'},
        sum:$.sum(1),
        phones:$.addToSet('$phone'),
      })
      .sort({_id:-1})
      .end()
      .then(res=>{
        //console.log(res.data)
        this.school.forEach((grade,index)=>{
        this.school[index].sum = res.data[index].sum;
        this.school[index].selected = res.data[index].sum;
        this.school[index].phones = res.data[index].phones;
        })
        //this.school[0].value = res.data;
      }).catch(console.error)
    },
    async getSchool(){
      const $ = this.db.command.aggregate
      await this.db.collection('students').aggregate()
      .match({inschool:2020})
      .group({
        _id: {inschool:'$inschool',inclass:'$inclass'},
        phones: $.addToSet('$phone'),
        students:$.addToSet({text:'$name',value:'$phone'}),
        selected:$.addToSet('$phone'),
        sum:$.sum(1),
        selectedAll:$.first(true),
      })
      .sort({_id:1})
      .end()
      .then(res=>{
        //console.log(res.data)
        this.school[0].value = res.data;
      }).catch(console.error)
      await this.db.collection('students').aggregate()
      .match({inschool:2019})
      .group({
        _id: {inschool:'$inschool',inclass:'$inclass'},
        phones: $.addToSet('$phone'),
        students:$.addToSet({text:'$name',value:'$phone'}),
        selected:$.addToSet('$phone'),
        sum:$.sum(1),
        selectedAll:$.first(true),
      })
      .sort({_id:1})
      .end()
      .then(res=>{
        //console.log(res.data)
        this.school[1].value = res.data;
        //console.log(this.school)
      }).catch(console.error)

    },
    async getClass(grade,inclass){
      var date = new Date();
      const year = date.getMonth()>=8?date.getFullYear():date.getFullYear()-1;
      const inschool =year-grade+1;
      const $ = this.db.command.aggregate

      await this.db.collection('students').aggregate()
      .match({inschool:inschool,inclass:inclass})
      .group({
        _id: {
          inschool: '$inschool',
          inclass: '$inclass'
        },
        phones: $.addToSet('$phone'),
        students:$.addToSet({text:'$name',value:'$phone'})
      })
      .end()
      .then(res=>{
        //console.log(res.data[0].students)
        this.flavours = res.data[0].students
        this.allphone = res.data[0].phones
        //this.names = res.data[0].names
      })
      /*
      await this.db.collection('students').where({inschool:inschool,inclass:inclass}).get()
      .then(res=>{this.classes = res.data;console.log(res.data)})
      .catch(console.error)
      */
     //await this.db.collection('students').
      //console.log(inschool,inclass);
    },

    /** Triggered by custom 'form-submitted' event from GameForm child component. 
     * Parses formData, and route pushes to 'quiz' with formData as query
     * @public
     */
    handleFormSubmitted(formData) {
      const query = formData
      query.difficulty = query.difficulty.toLowerCase()
      this.$router.push({ name: 'quiz', query: query })
    },
    chooseTemplate(content,title){
      this.sendmsg.content = content;
      this.sendmsg.title = title
      //console.log('1',this.sendmsg.content)
    },
    toggleAll(checked) {
        this.selected = checked ? this.allphone : []
      },
    toggleAllClass(index,indexx,cla){
    //console.log(this.school[index].value[indexx],cla);
    //console.log(this.school);
    if(this.school[index].value[indexx].selectedAll){
      this.school[index].selected -= this.school[index].value[indexx].sum
    }else{
      this.school[index].selected += this.school[index].value[indexx].sum
    }
    //console.log(this.school[index].selected)
    if(this.school[index].selectedAll&&cla.selectedAll){
      this.school[index].selectedAll= false;
    }else{
      if(this.school[index].sum==this.school[index].selected){
        this.school[index].selectedAll= true;
      }
    }
    this.school[index].value[indexx].selected = cla.selectedAll?[]:this.school[index].value[indexx].phones;
    this.school[index].value[indexx].selectedAll = !cla.selectedAll;
    },
    toggleAllGrade(index,grade){
    //console.log(this.school)
      this.school[index].value.forEach((cls,indexx)=>{
        this.school[index].value[indexx].selected = this.school[index].selectedAll?[]:this.school[index].value[indexx].phones;
        this.school[index].value[indexx].selectedAll = this.school[index].selectedAll?false:true;
      })
      this.school[index].selected = grade.selectedAll?0:grade.sum;
      this.school[index].selectedAll = !grade.selectedAll;

    },
  },
  watch: {
      selected(newVal) {
        // Handle changes in individual flavour checkboxes
        if (newVal.length === 0) {
          this.indeterminate = false
          this.allSelected = false
        } else if (newVal.length === this.flavours.length) {
          this.indeterminate = false
          this.allSelected = true
        } else {
          this.indeterminate = true
          this.allSelected = false
        }
      }
    }
}
/*
<!-- Element to collapse -->
    <div v-for="(grade,index) in school" :key="index" :v-if="false">
      <!-- <b-button v-b-toggle="grade.grade" class="m-1">{{grade.grade}}</b-button> -->
      <b-collapse :id="">
      <div v-for="(cla,indexx) in grade.value" :key="indexx" class="p-4">
      <b-form-checkbox
          v-model="cla.selectedAll"
          @change="toggleAllClass(index,indexx,cla)"
        >
        <div>{{grade.grade}}（{{cla._id.inclass-10}}）班 共{{cla.sum}}人 {{ cla.selectedAll ? '全选' : '未全选' }}</div>
          
        </b-form-checkbox>
        
          <div class="d-flex justify-content-start">

            <b-form-checkbox-group
              v-model="cla.selected"
              :options="cla.students"
              class="ml-4"
              stacked
            ></b-form-checkbox-group>
          </div>
      </div>
      </b-collapse>
    </div>
<!-- Element to collapse -->
 */
</script>
