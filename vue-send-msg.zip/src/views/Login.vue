<template>
  <b-container fluid class="modal-dialog" style="margin-top: 35%;">
  <b-form @submit="onSubmit" v-if="show">
        <div class="modal-content">
            <div class="modal-header custom-info">
 
                <h4 class="modal-title text-center text-white" id="myModalLabel">欢迎您</h4>
            </div>

            <div class="modal-body" id = "model-body">
                <div class="form-group">

                    <b-form-input
          id="input-2"
          v-model="form.name"
          required
          placeholder="请输入姓名"
        ></b-form-input>
                </div>
                <div class="form-group">
 
                    <b-form-input
          id="input-4"
          v-model="form.phone"
          required
          type='tel'
          placeholder="请输入手机号"
          @change="tel"
        ></b-form-input>

                </div>
            </div>

            <div class="modal-footer">
                <div class="form-group">
                    <b-button type="submit" class="btn btn-primary form-control">登录</b-button>
                </div>
            </div>
        </div><!-- /.modal-content -->
      </b-form>
  </b-container>
</template>

<script>
  export default {
    name:'Login',
    data() {
      return {
      form: {
          name: null,
          phone: null,
          grade:null,
          inclass:null
        },
        show:true,
      }
    },
    beforeCreate: async function() {
      if(this.$cookies.get('login')&&this.$cookies.get('form')){
        if(this.$cookies.get('form').name == this.$root.$data.name){
          this.$router.push({ name: 'sendmsgall', query: this.$cookies.get('form') })
        }else{
          this.$router.push({ name: 'sendmsg', query: this.$cookies.get('form') })
        }
        
      }
    },
    methods: {
    onSubmit(evt) {
        evt.preventDefault()
        this.getTeacher(this.form.name,this.form.phone);
      },
      /*
  数据库中phone,类型为num
   */
    async getTeacher(name,phone){
      await this.$cloud.auth({ persistence: "local" }).anonymousAuthProvider().signIn()
        const db = this.$cloud.database();
        this.db = this.$cloud.database();
        this.$root.$data.db  = this.$cloud.database();
        await db.collection('classes').where({phone:parseInt(phone),teacher:name}).get()
        .then(res=>{
          if(res.data.length>0){
            const classes = res.data[0];
            this.form.teacher = name;
            this.form.grade = classes.grade;
            this.form.inclass = classes.inclass;
            this.form.name = classes.name;
            this.$cookies.set('login','true','1y');
            this.$cookies.set('form',this.form,'1y');
            if(name==this.$root.$data.name){
              this.$router.push({ name: 'sendmsgall', query: this.form });
            }else{
              this.$router.push({ name: 'sendmsg', query: this.form });
            }
            
          }else{
            //没有查到指定班级，您还不是班主任，您的信息输入有误，请联系管理员添加。
          }
          
        })
        .catch(console.error)
    },
      tel(){
      if (!/^1[345789]\d{9}$/.test(this.form.phone)) {
        alert("请输入正确的手机号");
        this.form.phone = "";
      }
      }

    }
  }
</script>