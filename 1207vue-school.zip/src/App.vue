<template>
  <div id="app">
    <v-btn @click="login">登录</v-btn>
    <Login v-on:login="login()" v-if="showLogin"></Login>
    <Home v-on:logout="logout()" v-else></Home>
  </div>
</template>

<script>
import Login from "@/components/Login.vue"
import Home from "@/components/Home.vue"

export default {
  name: 'App',
  components: {
    Login,
    Home
  },
  data: () => ({
    showLogin:true
  }),
  methods:{
    login(){
      this.showLogin = false;
    },
    logout(){
      this.showLogin = true;
    }
  }
}
</script>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  // padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
