import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../components/Home.vue'
import Login from '../components/Login.vue'
import Welcome from '../views/Welcome.vue'
import Robot from '../views/Robot.vue'
import Msg from '../views/Msg.vue'
import SchoolMsg from '../views/SchoolMsg.vue'
import ShortMsg from '../views/ShortMsg.vue'
import Timer from '../views/Timer.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/timer',
    name: 'Timer',
    component: Timer
  },
  {
    path: '/home',
    name: 'Home',
    component: Home
  },
  {
    path: '/welcome',
    name: 'Welcome',
    component: Welcome
  },
  {
    path: '/robot',
    name: 'Robot',
    component: Robot
  },
  {
    path: '/msg',
    name: 'Msg',
    component: Msg
  },
  {
    path: '/schoolMsg',
    name: 'SchoolMsg',
    component: SchoolMsg
  },
  {
    path: '/shortMsg',
    name: 'ShortMsg',
    component: ShortMsg
  },
  {
    path: '/',
    name: 'Welcome',
    component: Welcome
  },
  {
    path: '/about',
    name: 'About',
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

const router = new VueRouter({
  mode:'history',
  routes
})

export default router
