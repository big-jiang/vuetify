<template>
<div>
  <v-item-group multiple>
    <v-container >
      <v-row class="px-16 mt-n10">
        <v-col
          v-for="n in 12"
          :key="n"
          cols="12"
          md="3"
        >
          <v-item v-slot="{ active, toggle }">
            <v-card
              :color="active ? 'light-blue darken-2' : 'grey'"
              class="d-flex align-center"
              dark
              height="60"
              @click="toggle"
            >
              <v-scroll-y-transition>
                <div
                  v-if="active"
                  class="title flex-grow-1 text-center"
                >
                  {{theme[n-1].text}}
                </div>
                <div
                  v-else
                  class="title flex-grow-1 text-center"
                >
                  {{theme[n-1].month}}月主题
                </div>
              </v-scroll-y-transition>
            </v-card>
          </v-item>
        </v-col>
      </v-row>
    </v-container>
  </v-item-group>

  <v-file-input
    accept="image/*"
    label="File input"
    @change="getFile"
    v-if="false"
  ></v-file-input>

  <v-textarea
    filled
    v-model="file"
    v-if="false"
  ></v-textarea>

  <v-card height="400px" v-if="false">
    <v-footer
      v-bind="localAttrs"
    >
      <v-card
        flat
        tile
        width="100%"
        class="primary lighten-1 text-center"
      >
        <v-card-text class="white--text">
          {{ new Date().getFullYear() }} — <strong>Bigjiang</strong>
        </v-card-text>
      </v-card>
    </v-footer>

    <v-row
      align="center"
      justify="center"
      class="ma-12"
    >
      <v-col
        cols="12"
        md="8"
      >
      </v-col>
    </v-row>
  </v-card>
  </div>
</template>

<script>
  export default {
    data: () => ({
      file:'图片Base64',
      theme:[{month:"一",text:"家庭游戏"},{month:"二",text:"儿童心理学"},
             {month:"三",text:"情绪管理"},{month:"四",text:"有效陪伴"},
             {month:"五",text:"身心保健"},{month:"六",text:"作业习惯"},
             {month:"七",text:"社交礼仪"},{month:"八",text:"儿童心理学"},
             {month:"九",text:"习惯养成"},{month:"十",text:"亲子陪伴"},
             {month:"十一",text:"营养健康"},{month:"十二",text:"学习方法"},
      ]
    }),
    computed: {
      localAttrs () {
        const attrs = {fixed:true}
        return attrs
      },
    },
     methods:{
      async getFile(file){
        // console.log(file.size>1024000)
        if(file==undefined||file.size>1024000){
            console.log('超出图片限制大小（1M）');
            return;
          }else{
            let image= await this.file2Image(file);
            this.file = image;
            // let url = await this.uploadImage(image,file.name,"uploadImage");
            // this.file = url;
          }
      },
      uploadImage(image,path,method){
        return new Promise((resolve) => {
          var url = this.$Global.api;
          var requireData = { imageBase64:image,phone: this.$Global.phone, path:path,method:method};
          this.$axios
            .post(url, requireData)
            .then((res) => {
              resolve(res.data.url)
            })
            .catch(function (error) {
              // 请求失败处理
              console.log(error);
            });
        });
      },
      file2Image(file) {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = function (e) {
            const data = e.target.result;
            resolve(data);
          };
          reader.readAsDataURL(file);
        });
      },
    }
  }
</script>