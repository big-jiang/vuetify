<template>
  <v-container class="grey lighten-5">
     <v-row>
      <v-col
        cols="12"
        md="6"
      >
        <video width="100%" controls src="https://dingrobotfiles.oss-cn-hangzhou.aliyuncs.com/systemfile/dingding0301-3.mp4"></video>
      </v-col>
      <v-col
        cols="12"
        md="6"
      >
        <video  width="100%" controls src="https://dingrobotfiles.oss-cn-hangzhou.aliyuncs.com/systemfile/dingding2019.3.1.mp4"></video>
      </v-col>
    </v-row>
  </v-container>
</template>
