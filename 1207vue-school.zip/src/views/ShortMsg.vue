<template>
  <v-container class="grey lighten-5">
    <my-snackbar :isShow="snackbar" :text="text"></my-snackbar>
  </v-container>
</template>

<script>
  export default {
    data: () => ({
      snackbar: true,
      text: '如有需要，请联系技术人员',
    }),
  }
</script>