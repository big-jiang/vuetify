const request = require('request');
// const md5 = require('md5');
//1.输入数据，点击查询，触发函数，将数据传入外部js文件中
//2.进行请求,等待大数据返回数据
//3.大数据返回数据预处理
//4.返回至"调用文件"
//5.赋值参数

const backData = [
    {
      personelNo: 330682,
      name: "张三",
      cardId: 321321199710057015,
      companyName: "浙江中软网络有限公司",
      tong_time: "2020-09-28 19:18:58.0",
    },
    {
      personelNo: 330681,
      name: "李四",
      cardId: 321321199710057015,
      companyName: "阿里巴巴电子商务（杭州）有限公司",
      tong_time: "2020-09-28 19:18:58.0",
    },
    {
      personelNo: 330684,
      name: "王五",
      cardId: 321321199710057015,
      companyName: "杭州钉钉网络科技有限责任公司",
      tong_time: "2020-09-28 19:18:58.0",
    },
    {
        personelNo: 330683,
        name: "赵六",
        cardId: 321321199710057015,
        companyName: "腾讯网络科技（深圳）有限公司",
        tong_time: "2020-09-28 19:18:58.0",
      },
  ];
async function getData(str='null'){
    console.log('form:',str);
    const promise= new Promise((resolve)=>{
        if(backData){
           resolve(getSecrect('getsecret'))
        }else{
            resolve('出现错误');
        }
    })
    return promise
}

//获取最新的请求秘钥
async function getSecrect(method){
    var options = {
        'method': 'POST',
        'url': `https://env-web-16c0e3-1258099036.ap-shanghai.service.tcloudbase.com/secrect?method=${method}`,
        'headers': {
            'Content-Type': 'application/json'
        }

    };
    const promise = new Promise((resolve,reject)=>{
        request(options, (error,response)=>{
            if (error){ console.log('1');reject('出现错误');throw new Error(error);}
            var res = JSON.parse(response.body);
            resolve(backData);
            //console.log(res);
            if(res.code==2){
                resolve('10')
                //使用bysec刷新秘钥
                //resolve(refresh('bysec',res.data.refreshSecret));
            }else if(res.code==3){
                //使用bykey刷新秘钥
                //resolve(refresh('bykey',appsec));
            }else{
                //请求秘钥有效
                //resolve(res.data.requestSecret);
            }
        });
    });
    return promise;
}

export default getData
