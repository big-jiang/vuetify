<template>
<div>
  <b-card-header class="custom-info text-white font-weight-bold">New Quiz</b-card-header>
  <b-card-body class="h-100">
    <GameForm @form-submitted="handleFormSubmitted"></GameForm>
  </b-card-body>
</div>
</template>

<script>
import GameForm from '../components/GameForm'

export default {
  name: 'MainMenu',
  components: {
    GameForm
  },
  mounted: function() {
    //console.log(this.$cookies.get('form'))
    if(!this.$cookies.get('form')){
      alert('您的账号已过期，请重新输入')
      this.$cookies.set('login','false','1min')
      this.$router.push({ name: 'login'})
    }
  },
  methods: {
    /** Triggered by custom 'form-submitted' event from GameForm child component. 
     * Parses formData, and route pushes to 'quiz' with formData as query
     * @public
     */
    handleFormSubmitted(formData) {
      const query = formData
      query.difficulty = query.difficulty.toLowerCase()
      this.$router.push({ name: 'quiz', query: query })
    }
  }
}
</script>

