import Vue from 'vue'
import App from './App.vue'
import router from './router'
import BootstrapVue from 'bootstrap-vue'
import * as Tcb from 'vue-tcb'
import VueCookies from 'vue-cookies'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.config.productionTip = false

Vue.use(BootstrapVue)

Vue.use(Tcb,{env: 'env-web-16c0e3'})

Vue.use(VueCookies)

Vue.directive('title', {
  inserted: function (el) {
    document.title = el.dataset.title
  }
})

const state = { questions: [] }

new Vue({
  router,
  data: state,
  render: h => h(App)
}).$mount('#app')
