import Vue from 'vue'
import App from './App.vue'
import router from './router'
import BootstrapVue from 'bootstrap-vue'
import * as Tcb from 'vue-tcb'
import VueCookies from 'vue-cookies'
import Vant  from 'vant';
import * as dd from 'dingtalk-jsapi';
import cloudbase from '@cloudbase/js-sdk'
import weui from 'weui.js';
import 'weui';

import { Checkbox } from 'ant-design-vue'
//import VConsole from 'vconsole'
import 'ant-design-vue/dist/antd.css'
import 'vant/lib/index.css';
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.config.productionTip = false

Vue.prototype['$cloud'] = cloudbase.init({env:'env-web-16c0e3'})

Vue.use(BootstrapVue)

Vue.use(Tcb,{env: 'env-web-16c0e3'})

Vue.use(VueCookies)

Vue.use(Checkbox)

Vue.use(Vant)

Vue.use(dd)
// Vue.use(vConsole)
// 
Vue.prototype.$weui = weui

Vue.directive('title', {
  inserted: function (el) {
    document.title = el.dataset.title
  }
})

const state = { questions: [] }

const basic = { title:"111"}

var config = {
	appkey:'dinglwymead7j5al9t6k',
	appsecret:'R0siJgZSs1h4g6xDeHIJ7Gb03IkrSfBCoptXTE68CFbp6JtaiZAMqqu9ltemOgW0',
	corpId:'ding42404b8dd027ed3535c2f4657eb6378f',
	url:'http://172.18.1.171:8080/'
}

const db = null

const cloud = null

const domain ="http://www.suiyijian.vip"

new Vue({
  router,
  data: {basic,state,db,dd,cloud,config},
  global:{domain},
  render: h => h(App)
}).$mount('#app')
