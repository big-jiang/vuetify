const request = require('request');
const md5 = require('md5');
const cloud = require('@cloudbase/node-sdk');

const app = cloud.init({env: 'env-web-16c0e3'});
const db = app.database();
var doc = '13c6ced75fa64634000d1fac6be7ef94';

var appkey = '03770de0b6d34d749812f64ab8d3984e';
var appsec = 'e50ad63da82148459a7a93512b7f98fa';

var reqUrl = 'http://172.23.31.13:80/gateway/api/001008006007122/dataSharing/e0d6DeZOTPc2iV47.htm';
var name = encodeURI('刘洋瑞');
var cardId = '342422199401156358';

main();

async function main(){
    let task = getSecrect('getsecret');
    let reqsec = await task;
    //数据请求
    //console.log(reqsec);
    console.log(await getData(reqsec));
}

//数据请求
async function getData(reqsec) {
    var newTime = new Date()
    var time = newTime.getTime();
    var str = appkey+reqsec+time;
    var sign = md5(str);
    var params = `requestTime=${time}&cardId=${cardId}&sign=${sign}&name=${name}&appKey=${appkey}`;
    var options = {
        'method': 'POST',
        'url': `${reqUrl}?${params}`,
        'headers': {
            'Content-Type': 'application/json'
        }
    }
    const promise = new Promise((resolve,reject)=>{
        request(options, (error,response)=>{
            if (error){ console.log('1');reject('出现错误');throw new Error(error);}
            var res = JSON.parse(response.body);
            resolve(res)
        });
    });
    return promise;
}

//获取最新的请求秘钥
async function getSecrect(method){
    var options = {
        'method': 'POST',
        'url': `https://env-web-16c0e3-1258099036.ap-shanghai.service.tcloudbase.com/secrect?method=${method}`,
        'headers': {
            'Content-Type': 'application/json'
        }

    };
    const promise = new Promise((resolve,reject)=>{
        request(options, (error,response)=>{
            if (error){ console.log('1');reject('出现错误');throw new Error(error);}
            var res = JSON.parse(response.body);
            //console.log(res);
            if(res.code==2){
                //使用bysec刷新秘钥
                resolve(refresh('bysec',res.data.refreshSecret));
            }else if(res.code==3){
                //使用bykey刷新秘钥
                resolve(refresh('bykey',appsec));
            }else{
                //请求秘钥有效
                resolve(res.data.requestSecret);
            }
        });
    });
    return promise;
}
//刷新秘钥
async function refresh(method,refsec){
    var newTime = new Date()
    var time = newTime.getTime();
    var str = appkey+refsec+time;
    var sign = md5(str);
    var url = method=='bysec'?'http://172.23.31.13:80/gateway/app/refreshTokenBySec.htm':'http://172.23.31.13:80/gateway/app/refreshTokenByKey.htm';
    var param = `requestTime=${time}&sign=${sign}&appKey=${appkey}`;
    var options = {
        'method': 'POST',
        'url': `${url}?${param}`,
        'headers': {
            'Content-Type': 'application/json'
        }
    }
    const promise = new Promise((resolve,reject)=>{
        request(options, (error,response)=>{
            if (error){ console.log('1');reject('出现错误');throw new Error(error);}
            //获取到新的请求秘钥
            //秘钥持久化
            //console.log('新请求秘钥',JSON.parse(response.body).datas.requestSecret);
            saveSecret('savesecret',JSON.stringify(JSON.parse(response.body).datas))
            resolve(JSON.parse(response.body).datas.requestSecret);
        });
    });
    return promise;
}
//持久化秘钥
async function saveSecret(method,body){
    var options = {
        'method': 'POST',
        'url': `https://env-web-16c0e3-1258099036.ap-shanghai.service.tcloudbase.com/secrect?method=${method}&data=${body}`,
        'headers': {
            'Content-Type': 'application/json'
        }

    };
    request(options, function (error, response) {
        if (error) throw new Error(error);
        var res = JSON.parse(response.body);
        if(res.updated){
            //更新完成
            console.log('秘钥更新 updated：',res.updated);
        }else{
            //出现错误
        }
        //
    });
}