<template>
  <div>
    <v-overlay :value="overlay">
      <v-progress-circular
        indeterminate
        size="64"
      ></v-progress-circular>
    </v-overlay>

    <v-row justify="space-around">
    <v-col
      cols="12"
      sm="10"
      md="10"
    >
      <v-sheet
        elevation="10"
        class="py-4 px-1"
      >
        <v-chip-group
          v-model="selectedApi"
        multiple
        mandatory
        >
          <v-chip
          filter
          outlined
            v-for="item in api"
            :key="item.index"
          >
            {{ item.text }}
          </v-chip>
        </v-chip-group>
      </v-sheet>
    </v-col>
  </v-row>

    <v-form ref="form" v-model="valid" lazy-validation>
      <v-container>
        <v-row>
          <v-col cols="12" md="3">
            <v-text-field
              v-model="form.name"
              :rules="nameRules"
              :counter="20"
              label="姓名"
              required
            ></v-text-field>
          </v-col>

          <v-col cols="12" md="3">
            <v-text-field
              v-model="form.cardId"
              :rules="cardRules"
              label="身份证号"
              required
            ></v-text-field>
          </v-col>
          <v-col cols="12" md="3" >
            <v-text-field
              v-model="form.uniscId"
              label="统一社会信用代码"
              v-if="showUniscId"
            ></v-text-field>
          </v-col>

          <v-col cols="12" md="3">
            <v-btn
              :disabled="!valid"
              color="primary"
              class="mr-4"
              @click="validate"
            >
              查询
            </v-btn>
          </v-col>
        </v-row>
      </v-container>
    </v-form>
    <v-divider></v-divider>

    <v-dialog v-model="dialogAlert" max-width="500px">
              <v-card>
                <v-card-title class="headline"
                  >{{dialogAlertText}}</v-card-title
                >
                <!-- <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closeDelete"
                    >Cancel</v-btn
                  >
                  <v-btn color="blue darken-1" text @click="deleteItemConfirm"
                    >OK</v-btn
                  >
                  <v-spacer></v-spacer>
                </v-card-actions> -->
              </v-card>
            </v-dialog>
<v-snackbar v-model="snackbar" :timeout="timeout" top>
      {{ text }}

      <template v-slot:action="{ attrs }">
        <v-btn color="blue" text v-bind="attrs" @click="snackbar = false">
          Close
        </v-btn>
      </template>
    </v-snackbar>
<template class="">
  <v-file-input 
    class="mx-6"
    outlined
    dense
    show-size
    label="请选择文件（xls或xlsx）" 
    accept=".xls, .xlsx" 
    @change="uploadFile"
    ></v-file-input>
      <v-data-table
        v-model="selected"
        item-key="cardId"
        :headers="headersPerson"
        :items="desserts"
        :search="search"
        class="elevation-1 ma-6"
        show-select
        :loading="loading"
        loading-text="加载数据中... 请稍等"
        :footer-props="{
          itemsPerPageText: '每页数量',
          itemsPerPageOptions: [10, 20, 50, -1],
          itemsPerPageAllText: '全部',
        }"
      >
        <template v-slot:headersPerson.name="{ headersPerson }">
          {{ headersPerson.text.toUpperCase() }}
        </template>
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>批量人员选择</v-toolbar-title>
            <v-divider class="mx-4" inset vertical></v-divider>
            <v-text-field
              v-model="search"
              append-icon="mdi-magnify"
              label="实时搜索"
              single-line
              hide-details
            ></v-text-field>
            <v-spacer></v-spacer>
            <v-btn
                  color="blue-grey mr-6"
                  dark
                  class="mb-2 white--text"
                  @click="selected=[]"
                >
                  重置
                </v-btn>

            <v-btn
                  :loading="loading3"
                  :disabled="loading3"
                  color="primary"
                  dark
                  class="mb-2 white--text"
                  @click="piSearch"
                  loader = 'loading3'
                >
                  批量查询
                  <v-icon right dark> mdi-cloud-download </v-icon>
                </v-btn>
            <v-dialog v-model="dialog" max-width="1000px">
              <!-- <template v-slot:activator="{ on, attrs }">
                <v-btn
                  :loading="loading3"
                  :disabled="loading3"
                  color="blue-grey"
                  dark
                  class="mb-2 white--text"
                  v-bind="attrs"
                  v-on="on"
                  @click="loader = 'loading3'"
                >
                  打印
                  <v-icon right dark> mdi-cloud-upload </v-icon>
                </v-btn>
              </template> -->

              <v-card  id="0">
                <v-card-title >
                  <span class="headline">个人查询信息</span>
                </v-card-title>

                <v-card-text class="my-10 ">
                  <v-container>
                     <table class="black--text" style="border-style: solid;border-width: 1.0pt;font-variant: normal;" id="printpdf">
            <!-- 12，3*100，600，100+200+300 -->
            <tr >
              <td align="center" colspan="1" width="100">姓名</td>
              <td align="center" colspan="1" width="100">{{person.name||''}}</td>
              <td align="center" colspan="1" width="100">身份证号</td>
              <td align="center" colspan="2" width="200">{{person.cardId||''}}</td>
              <td align="center" colspan="1" width="100">参保企业</td>
              <td align="center" colspan="3" width="300">{{person.result[1].companyName||''}}</td>
            </tr>
            <tr >
              <td align="center" colspan="1" width="100">户籍信息</td>
              <td align="center" colspan="8" width="800">{{person.result[8].persons}}</td>
            </tr>

            <!-- 12，4*100，600，100+200+300 -->
            <tr >
              
              <td align="center" colspan="1" width="100">车辆品牌</td>
              <td align="center" colspan="1" width="100">{{person.result[0].cLPP1}}</td>
              <td align="center" colspan="1" width="100">车辆型号</td>
              <td align="center" colspan="1" width="100">{{person.result[0].cLLX}}</td>
              <td align="center" colspan="1" width="100">车牌号</td>
              <td align="center" colspan="1" width="100">{{person.result[0].hPHM}}</td>
              <td align="center" colspan="1" width="100">汽车状态</td>
              <td align="center" colspan="2" width="200">{{person.result[0].sYXZ}}</td>
              
            </tr>
            <tr >
              <td align="center" colspan="1" width="100">养老状态</td>
              <td align="center" colspan="1" width="100">{{person.result[6].dyffzt}}</td>
              <td align="center" colspan="1" width="100">养老类型</td>
              <td align="center" colspan="1" width="100">{{person.result[6].dylx}}</td>
              <td align="center" colspan="1" width="100">养老金额</td>
              <td align="center" colspan="1" width="100">{{person.result[6].dysp}}</td>
              <td align="center" colspan="1" width="100">起止时间</td>
              <td align="center" colspan="2" width="200">{{person.result[6].jfmin}}-{{person.result[6].jfmax}}</td>
            </tr>
            <tr >
              <td align="center" colspan="1" width="100">社保状态</td>
              <td align="center" colspan="1" width="100">{{person.result[7].gszt}}</td>
              <td align="center" colspan="1" width="100">社保类型</td>
              <td align="center" colspan="3" width="300">{{person.result[7].aab004}}</td>
              <td align="center" colspan="1" width="100">起止时间</td>
              <td align="center" colspan="2" width="200">{{person.result[7].jfmin}}-{{person.result[7].jfmax}}</td>
            </tr>
            <tr >
              <td align="center" colspan="1" width="100">救助状态</td>
              <td align="center" colspan="1" width="100">{{person.result[4].mzpyy}}</td>
              <td align="center" colspan="1" width="100">救助原因</td>
              <td align="center" colspan="1" width="100">{{person.result[5].sam00}}</td>
              <td align="center" colspan="1" width="100">低保金额</td>
              <td align="center" colspan="1" width="100">{{person.result[4].mzjzje}}</td>
              <td align="center" colspan="1" width="100">边缘状态</td>
              <td align="center" colspan="2" width="200">{{person.result[5].mzpyy}}</td>
              
            </tr>
            <tr v-if="person.result[3].companys!=''">
              <td align="center" colspan="1" width="100">名下企业</td>
              <td align="center" colspan="8" width="800">{{person.result[3].companys}}</td>
            </tr>
            <tr v-for="item in person.result[2].fc" :key="item.bdcqzh">
              <td align="center" colspan="1" width="100">不动产</td>
              <td align="center" colspan="2" width="300">{{item.bdcqzh}}</td>
              <td align="center" colspan="3" width="300">{{item.mj}}</td>
              <td align="center" colspan="3" width="300">{{item.zl}}</td>
            </tr>
            
          </table>
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="close">
                    取消
                  </v-btn>
                  <v-btn color="success darken-1" text @click="print">
                    打印
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
            <!-- <v-dialog v-model="dialogDelete" max-width="500px">
              <v-card>
                <v-card-title class="headline"
                  >Are you sure you want to delete this item?</v-card-title
                >
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closeDelete"
                    >Cancel</v-btn
                  >
                  <v-btn color="blue darken-1" text @click="deleteItemConfirm"
                    >OK</v-btn
                  >
                  <v-spacer></v-spacer>
                </v-card-actions>
              </v-card>
            </v-dialog> -->
          </v-toolbar>
        </template>

        <template v-slot:item.actions="{item}">
          <v-icon small class="mr-2" @click="editItem(item)">
            mdi-eye
          </v-icon>
          <!-- <v-icon small @click="deleteItem(item)"> mdi-delete </v-icon> -->
        </template>
        <template v-slot:no-data>
          <!-- <v-btn color="primary" @click="initialize"> 重置 </v-btn> -->
          <div class="ma-6">请先选择数据文件，然后选择需要查询的人员，再点击批量查询</div>
        </template>
      </v-data-table>
    </template>
<v-dialog v-model="dieDialog" max-width="500px">

              <v-card  id="0">
                <v-card-title >
                  <span class="headline">绍兴市火化信息（批量）导出</span>
                </v-card-title>

                <v-card-text class="my-10 text-subtitle-1">
                  <v-container> 
                    点击下方按钮可导出数据！
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="success darken-1" text  @click="dieDialog=false">
                  <download-excel
                    class="btn btn-default"
                    :data="json_data"
                    :fields="json_fields"
                    worksheet="sheet1"
                    type="csv"
                    name="绍兴市火化信息(批量)导出.csv"
                  >
                    导出EXCEL
                  </download-excel>
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
    <template class="" v-if="false">
      <v-data-table
        v-model="selected"
        item-key="name"
        :headers="headers"
        :items="desserts"
        :search="search"
        sort-by="cardId"
        class="elevation-1 ma-6"
        show-select
        :loading="loading"
        loading-text="加载数据中... 请稍等"
        :footer-props="{
          itemsPerPageText: '每页数量',
          itemsPerPageOptions: [10, 20, 50, -1],
          itemsPerPageAllText: '全部',
        }"
      >
        <template v-slot:header.name="{ header }">
          {{ header.text.toUpperCase() }}
        </template>
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>企业养老保险参保人员</v-toolbar-title>
            <v-divider class="mx-4" inset vertical></v-divider>
            <v-text-field
              v-model="search"
              append-icon="mdi-magnify"
              label="实时搜索"
              single-line
              hide-details
            ></v-text-field>
            <v-spacer></v-spacer>
            <v-dialog v-model="dialog" max-width="500px">
              <template v-slot:activator="{ on, attrs }">
                <v-btn
                  :loading="loading3"
                  :disabled="loading3"
                  color="blue-grey"
                  dark
                  class="mb-2 white--text"
                  v-bind="attrs"
                  v-on="on"
                  @click="loader = 'loading3'"
                >
                  打印
                  <v-icon right dark> mdi-cloud-upload </v-icon>
                </v-btn>
              </template>

              <v-card>
                <v-card-title>
                  <span class="headline">{{ formTitle }}</span>
                </v-card-title>

                <v-card-text>
                  <v-container>
                    <v-row v-if="formTitle == '编 辑'">
                      <v-col cols="12" sm="6" md="4">
                        <v-text-field
                          v-model="editedItem.personelNo"
                          :label="headers[0].text"
                        ></v-text-field>
                      </v-col>

                      <v-col cols="12" sm="6" md="4">
                        <v-text-field
                          v-model="editedItem.name"
                          :label="headers[1].text"
                        ></v-text-field>
                      </v-col>
                      <v-col cols="12" sm="6" md="4">
                        <v-text-field
                          v-model="editedItem.cardId"
                          :label="headers[2].text"
                        ></v-text-field>
                      </v-col>
                      <v-col cols="12" sm="6" md="4">
                        <v-text-field
                          v-model="editedItem.companyName"
                          :label="headers[3].text"
                        ></v-text-field>
                      </v-col>
                      <v-col cols="12" sm="6" md="4">
                        <v-text-field
                          v-model="editedItem.tong_time"
                          :label="headers[4].text"
                        ></v-text-field>
                      </v-col>
                    </v-row>
                    <v-row v-else>{{ selected }}</v-row>
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="close">
                    取消
                  </v-btn>
                  <v-btn color="success darken-1" text @click="save">
                    确认
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
            <!-- <v-dialog v-model="dialogDelete" max-width="500px">
              <v-card>
                <v-card-title class="headline"
                  >Are you sure you want to delete this item?</v-card-title
                >
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closeDelete"
                    >Cancel</v-btn
                  >
                  <v-btn color="blue darken-1" text @click="deleteItemConfirm"
                    >OK</v-btn
                  >
                  <v-spacer></v-spacer>
                </v-card-actions>
              </v-card>
            </v-dialog> -->
          </v-toolbar>
        </template>

        <template v-slot:item.actions="{item}">
          <v-icon small class="mr-2" @click="editItem(item)">
            mdi-pencil
          </v-icon>
          <!-- <v-icon small @click="deleteItem(item)"> mdi-delete </v-icon> -->
        </template>
        <template v-slot:no-data>
          <!-- <v-btn color="primary" @click="initialize"> 重置 </v-btn> -->
          <div class="ma-6">请输入相关数据，然后点击查询</div>
        </template>
      </v-data-table>
    </template>
    
  </div>
</template>

<script>
import getData from "../plugins/getData.js";
import XLSX from "xlsx";
import printJS from 'print-js';

export default {
  data: () => ({
    //火化
    dieDialog:false,
    json_data:[],
    json_fields: {
      "姓名": "sXM",
      "身份证号":"sSFZ",
      "死亡时间":"sSWSJ",
      "死亡原因":"sZSZYJB",
      "火化殡仪馆":"sBYG",
      "火化时间":"sHHSJ"
    },
    //个人展示打印
    person:{name:'',cardId:'',
    result:[
      {cLLX:'',cLPP1: '',hPHM: '',sYXZ: '',},
      {companyName:''},
      {fc:[{bdcqzh:'',mj:'',zl:''}]},
      {companys:''},
      {mzjzje:'',mzpyy:''},
      {mzpyy:'',sam00:''},
      {dyffzt:'',dylx:'',dysp:'',jfmin:'',jfmax:''},
      {aab004:'',gszt:'',jfmin:'',jfmax:''},
      {persons:''},
    ]},
    //遮罩层
    overlay:false,
    //提示语
    snackbar: false,
    text: "My timeout is set to 2000.",
    timeout: 2000,
    loading3: false,
    //接口列表选择
    api:[
        {text:'个人车辆信息',index:0},
        {text:'企业养老保险参保人员信息查询',index:1},
        {text:'绍兴不动产登记查询总接口',index:2},
        {text:'企业登记信息',index:3},
        {text:'低保救助信息',index:4},
        {text:'低保边缘信息',index:5},
        {text:'个人社保养老待遇发放情况',index:6},
        {text:'个人社保信息查询',index:7},
        {text:'户籍信息',index:8},
        {text:'绍兴市火化信息',index:9},
    ],
    selectedApi:[0,1,2,4,5,6,7,8],
    showUniscId:false,
    //table
    loading: false,
    search: "",
    selected: [],
    dialogAlert:false,
    dialogAlertText:'未查询到数据！！！',
    dialog: false,
    dialogDelete: false,
    headersPerson: [
      { align: "center",text: "姓名", value: "name" },
      { align: "center",text: "身份证号", value: "cardId" },
      { align: "center",text: "接口", value: "api" },
      { align: "center",text: "其他", value: "other" },
      { align: "center",text: "操作", value: "actions", sortable: false },
    ],
    headers: [
      {
        text: "人员编号",
        align: "start",
        sortable: false,
        value: "personelNo",
      },
      { text: "姓名", value: "name" },
      { text: "身份证号", value: "cardId" },
      { text: "参保企业名称", value: "companyName" },
      { text: "时间", value: "tong_time" },
      { text: "操作", value: "actions", sortable: false },
    ],
    desserts: [],
    editedIndex: -1,
    editedItem: {
      name: "",
      cardId: 0,
      companyName: 0,
      tong_time: 0,
      personelNo: 0,
    },
    defaultItem: {
      name: "0",
      cardId: 0,
      companyName: 0,
      tong_time: 0,
      personelNo: 0,
    },
    //form
    valid: false,
    form: {
      name: "",
      cardId: "",
      uniscId: "",
    },
    nameRules: [
      (v) => !!v || "请输入姓名",
      (v) => v.length <= 20 || "姓名最长为20个字符",
    ],
    cardRules: [(v) => !!v || "请输入正确的身份证号"],
    // uniscIdRules: [(v) => !!v || "请输入正确的身份证号"],
  }),
  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "打 印" : "编 辑";
    },
  },

  watch: {
    // selectedApi(val){
    //   // console.log(val.includes(3));
    //   if(val.includes(9)){
    //     this.selectedPop();
    //   }
    //   // this.showUniscId = val.includes(3);
    // },
    dialog(val) {
      val || this.close();
    },
    dialogDelete(val) {
      val || this.closeDelete();
    },
    dialogAlert (val) {
        if (!val) return
        setTimeout(() => (this.dialogAlert = false), 1500)
      },
  },

  created() {
    this.initialize();
    // console.log(this)
  },

  methods: {
    async piSearch(){
      //console.log(this.selected)
      if(this.selected==[]){return}
      console.log(this.selectedApi.includes(9));
      this.overlay = true;
      if(this.selectedApi.includes(9)){
          var cardList = this.selected.map(function(item){return item.cardId});
          var dieTask = await getData({name:'',cardId:cardList.toString()},[9]);
          this.json_data = dieTask.result[0].die;
          this.dieDialog = true;
      }else{
        for(var i=0;i<this.selected.length;i++){
          var task = await getData(this.selected[i],this.selectedApi);
          //console.log(task);
          if (typeof task == "object") {
            //this.desserts = task;
            console.log('task',task);
          } else {
            //查询提示
            //this.dialogAlert=true;
            //console.log(task);
          }
        }
      }
      this.overlay = false;
    },
    async uploadFile(event) {
      try {
        if (typeof event == "undefined") {
          return;
        }
        this.overlay = true;
        const file = event;
        const types = file.name.split(".")[1];
        const fileType = ["xlsx", "xls"].some((item) => item === types);
        if (!fileType) {
          this.snackbar = true;
          return (this.text = "文件类型错误，请重新选择"); //注意此处的$snackbar()是vuetify框架中的组件，此处改为自己使用的组件即可
        }
        let fileList = [];
        let tabJson = await this.file2Xce(file);
        if (tabJson && tabJson.length > 0) {
          this.xlsxJson = tabJson;
          fileList = this.xlsxJson[0].sheet;
          //console.log(fileList);
          this.overlay = false;
          this.desserts = fileList;
          //event.target.value = ""; // 解决上传相同附件只传一次问题，可以参考博文：https://blog.csdn.net/weixin_43363871/article/details/106716737
        }
      } catch (error) {
        console.log(error);
        this.overlay = false;
      }
    },
    file2Xce(file) {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = function (e) {
          const data = e.target.result;
          this.wb = XLSX.read(data, {
            type: "binary",
          });
          const result = [];
          const sheet2JSONOpts = {
            defval: "", //给defval赋值为空的字符串
          };
          this.wb.SheetNames.forEach((sheetName) => {
            result.push({
              sheetName: sheetName,
              sheet: XLSX.utils.sheet_to_json(
                this.wb.Sheets[sheetName],
                sheet2JSONOpts //当excel内容为空时若不加此属性没有相应的字段，可以取消试试效果
              ),
            });
          });
          resolve(result);
        };
        reader.readAsBinaryString(file);
      });
    },
    async validate() {
      this.$refs.form.validate();
      if (this.form.name && this.form.cardId) {
        // if(this.showUniscId&&this.form.uniscId==''){return}
        this.resetPerson();
        this.overlay = true;
        //查询请求
        var task = await getData(this.form,this.selectedApi);
        //console.log(task);
        if (typeof task == "object") {
          var res = task.result;
          this.person.name = task.name;
          this.person.cardId = task.cardId;
          for(var n=0;n<res.length;n++){
            if(res[n]==null){
              continue;
            }else{
              this.person.result[res[n].index]=res[n];
            }
          }
          //this.desserts = task;
          console.log('task',task);
          this.overlay = false;
        this.dialog = true;
        } else {  
          this.overlay = false;
        //查询提示
          this.dialogAlert=true;
          //console.log(task);
        }
        
      }
    },
    initialize() {
      this.selectedApi=[0,1,2,3,4,5,6,7,8];
      // this.selectedApi=[9];
      this.form.name = '丁大将';
      this.form.cardId = '321321199710057015';
    },
    resetPerson(){
      this.person = {name:'',cardId:'',
    result:[
      {cLLX:'',cLPP1: '',hPHM: '',sYXZ: '',},
      {companyName:''},
      {fc:[{bdcqzh:'',mj:'',zl:''}]},
      {companys:''},
      {mzjzje:'',mzpyy:''},
      {mzpyy:'',sam00:''},
      {dyffzt:'',dylx:'',dysp:'',jfmin:'',jfmax:''},
      {aab004:'',gszt:'',jfmin:'',jfmax:''},
      {persons:''},
    ]};
    },
    async editItem(item) {
      this.resetPerson();
      this.overlay = true;
      var task = await getData(item,this.selectedApi);
        //console.log(task);
        if (typeof task == "object") {
          var res = task.result;
          this.person.name = task.name;
          this.person.cardId = task.cardId;
          for(var n=0;n<res.length;n++){
            if(res[n]==null){
              continue;
            }else{
              this.person.result[res[n].index]=res[n];
            }
          }
          console.log('task',task);
        } else {
          //查询提示
          //this.dialogAlert=true;
          //console.log(task);
        }
      this.overlay = false;
      //查询请求
      //返回数据
      //数据赋值（可能会为空）
      this.dialog = true;
    },

    deleteItem(item) {
      this.editedIndex = this.desserts.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialogDelete = true;
    },

    deleteItemConfirm() {
      this.desserts.splice(this.editedIndex, 1);
      this.closeDelete();
    },

    close() {
      this.dialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    closeDelete() {
      this.dialogDelete = false;
      
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    save() {
      if (this.editedIndex > -1) {
        Object.assign(this.desserts[this.editedIndex], this.editedItem);
      } else {
        //this.desserts.push(this.editedItem);
      }
      this.close();
    },
     print(){
      //printJS({printable:this.someJSONdata,properties:['name','email','phone'],type:'json'});
      this.close();
      const style = '@page {  } ' +'@media print {.table{border-style: solid;border-width: 1.0pt;font-variant: normal;} td{border: 1px solid;}}' ;
      printJS({ printable: 'printpdf', type: 'html',style:style,header: '<h4>接口信息查询</h4>',gridStyle: 'border: 1px solid;'});
    }
  },
};
</script>

  <style type="text/css">
      @import url("../css/printstylesheet.css");
  </style>
  <style scoped>
  .table p {
    text-align: center;
    margin: 10px 0;
    color: #000c17;
    font-size: 18px;
  }
  .table{
    border-style: solid;
    border-width: 1.0pt;
    font-variant: normal;
  }
  td{
    border-style: solid;
    border-width: 1.0pt;
  }
  .centent > p{
    float: left;
    font-size: 18px;
    font-variant: normal;
    color: #000c17;
  }
  .tables{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  #pdfDom{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .title{
    font-size: 30px;
    font-variant: normal;
  }
</style>