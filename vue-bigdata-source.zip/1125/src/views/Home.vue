<template>
  <div>
    <v-row justify="center">
      <div
        class="tables"
        id="printhtml"
      >
        <div style="width: 1000px" id="pdfDom">
          <!-- <p align="center" class="title">中百物业收款收据</p> -->
          <table class="table" id="printpdf">
            <!-- 12，3*100，600，100+200+300 -->
            <tr >
              <td colspan="1" width="100">姓名</td>
              <td colspan="1" width="100">丁大将</td>
              <td colspan="1" width="100">身份证号</td>
              <td colspan="3" width="200">321321199710057015</td>
              <td colspan="1" width="100">参保公司</td>
              <td colspan="4" width="300">杭州随意兼网络科技有限责任公司</td>
            </tr>
            <tr >
              <td colspan="1" width="100">户籍信息</td>
              <td colspan="9" width="600">竹晓川(子),竹顺江(户主),陈棋芳(妻),陈香凤(母亲)</td>
            </tr>

            <!-- 12，4*100，600，100+200+300 -->
            <tr >
              <td colspan="1" width="100">车型</td>
              <td colspan="2" width="200">小型普通客车</td>
              <td colspan="1" width="100">品牌</td>
              <td colspan="2" width="200">奥迪牌</td>
              <td colspan="1" width="100">车牌号</td>
              <td colspan="1" width="100">浙D7F6G2</td>
              <td colspan="1" width="100">汽车状态</td>
              <td colspan="1" width="100">非运营</td>
            </tr>
            <tr >
              <td colspan="1" width="150">养老待遇状态</td>
              <td colspan="2" width="150">正常发放</td>
              <td colspan="1" width="100">养老类型</td>
              <td colspan="2" width="200">基本养老保险</td>
              <td colspan="1" width="100">社保金额</td>
              <td colspan="1" width="100">1906.85</td>
              <td colspan="1" width="100">起止时间</td>
              <td colspan="1" width="200">201811-202010</td>
            </tr>
            <tr >
              <td colspan="1" width="150">个人社保状态</td>
              <td colspan="2" width="150">终止缴费</td>
              <td colspan="1" width="100">社保类型</td>
              <td colspan="4" width="300">灵活就业人员(78888888)</td>
              <td colspan="1" width="100">起止时间</td>
              <td colspan="1" width="200">201811-202010</td>
            </tr>
            <tr >
              <td colspan="1" width="100">救助状态</td>
              <td colspan="2" width="200">低保户（救助）</td>
              <td colspan="1" width="100">总低保金额</td>
              <td colspan="1" width="100">800.00</td>
              <td colspan="1" width="100">边缘状态</td>
              <td colspan="2" width="200">低保户（边缘）</td>
              <td colspan="1" width="100">救助原因</td>
              <td colspan="1" width="200">因病致贫户</td>
            </tr>

            <!-- <tr v-for="(item,index) in receiptData" :key="index"> -->
            <tr>
              <td colspan="2" width="200">丁大将</td>
              <td colspan="2" width="170">321321199710057015</td>
              <td colspan="2" width="170">杭州随意兼网络科技有限责任公司</td>
              <td colspan="2" width="170">105</td>
              <td colspan="2" width="170">dingdajiang</td>
            </tr>
            <tr>
              <td colspan="2" width="300">合计(人民币大写)</td>
              <td colspan="6" width="220"></td>
              <td colspan="2" width="220">1000.00</td>
            </tr>
          </table>
        </div>
      </div>

    </v-row>
    <v-row><v-col>10.0.0</v-col>
    <v-col>10.0.0</v-col></v-row>
    
    <img alt="Vue logo" src="../assets/logo.png">
    <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
    <v-btn
@click="print"
>PRINT
</v-btn>
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'
import printJS from 'print-js';

export default {
  name: 'Home',
  components: {
    // HelloWorld
  },
  data: () => ({
    someJSONdata:[
            {name:'dingdajiang',email:'321321199710057015',phone:'18258169722'},
            {name:'dingdajiang',email:'321321199710057015',phone:'18258169722'},
            {name:'dingdajiang',email:'321321199710057015',phone:'18258169722'},
        ]
  }),
  methods:{
    print(){
      //printJS({printable:this.someJSONdata,properties:['name','email','phone'],type:'json'});
      const style = '@page {  } ' +'@media print {.table{border-style: solid;border-width: 1.0pt;font-variant: normal;} td{border-style: solid;border-width: 1.0pt;}}' ;
      printJS({ printable: 'printpdf', type: 'html',style:style});
    }
  }
}
</script>

  <style type="text/css">
      @import url("../css/printstylesheet.css") print;
  </style>

<style scoped>
  .table p {
    text-align: center;
    margin: 10px 0;
    color: #000c17;
    font-size: 18px;
  }
  .table{
    border-style: solid;
    border-width: 1.0pt;
    font-variant: normal;
  }
  td{
    border-style: solid;
    border-width: 1.0pt;
  }
  .centent > p{
    float: left;
    font-size: 18px;
    font-variant: normal;
    color: #000c17;
  }
  .tables{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  #pdfDom{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .title{
    font-size: 30px;
    font-variant: normal;
  }
</style>