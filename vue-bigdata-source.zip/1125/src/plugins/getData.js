const request = require('request');
const md5 = require('md5');

var appkey = '03770de0b6d34d749812f64ab8d3984e';
var appsec = 'e50ad63da82148459a7a93512b7f98fa';

//var reqUrl = 'http://172.23.31.13:80/gateway/api/001008006007007/dataSharing/personalCarInfo.htm';
//var reqUrl = 'http://172.23.31.13:80/gateway/api/001008006007122/dataSharing/e0d6DeZOTPc2iV47.htm';
//var reqUrl = 'http://172.23.31.13:80/gateway/api/001008006007122/dataSharing/4hObZxdex1319971.htm';
//var reqUrl = 'http://172.23.31.13:80/gateway/api/001076/dataSharing/enterpriseRegInfo.htm';
//var reqUrl = 'http://172.23.31.13/gateway/api/001008006007008/dataSharing/lowRescueInfo.htm';
//var reqUrl = 'http://172.23.31.13/gateway/api/001008006007008/dataSharing/lowMarginInfo.htm';
//var reqUrl = 'http://172.23.31.13/gateway/api/001008006007011/dataSharing/UF8794a3UpLfKoP0.htm';
//var reqUrl = 'http://172.23.31.13/gateway/api/001008006007011/dataSharing/1defS0Vb1lLiD9de.htm';
//var reqUrl = 'http://172.23.31.13/gateway/api/001008006007007/dataSharing/allHouseholdRegistrationInfo.htm';
//var reqUrl = 'http://172.23.31.13:80/gateway/api/001104/dataSharing/sxCremationInfoNew.htm';
var name = '';
var cardId = '';
var apiArr = [];

async function main(str = 'null', api) {
    name = str.name;
    cardId = str.cardId;
    apiArr = api;
    let task = getSecrect('getsecret');
    let reqsec = await task;
    //数据请求
    //console.log(reqsec);
    var bigData = await getData(reqsec);
    //console.log('back',bigData);
    const promise = new Promise((resolve) => {
        resolve(bigData)
    })
    return promise
}

//数据请求
async function getData(reqsec) {
    var newTime = new Date()
    var time = newTime.getTime();
    var str = appkey + reqsec + time;
    var sign = md5(str);
    var arr =
        [{
            api: '个人车辆信息',
            reqUrl: 'http://172.23.31.13:80/gateway/api/001008006007007/dataSharing/personalCarInfo.htm',
            params: `requestTime=${time}&sfzmhm=${cardId}&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '企业养老保险参保人员',
            reqUrl: 'http://172.23.31.13:80/gateway/api/001008006007122/dataSharing/e0d6DeZOTPc2iV47.htm',
            params: `requestTime=${time}&cardId=${cardId}&sign=${sign}&name=${name}&appKey=${appkey}`,
        }, {
            api: '绍兴不动产登记查询总接口',
            reqUrl: 'http://172.23.31.13:80/gateway/api/001008006007122/dataSharing/4hObZxdex1319971.htm',
            params: `requestTime=${time}&QLRZJH=${cardId}&QLRMC=${name}&dispatchCode=330683&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '企业登记信息',
            reqUrl: 'http://172.23.31.13:80/gateway/api/001076/dataSharing/enterpriseRegInfo.htm',
            params: `requestTime=${time}&sfzjhm=${cardId}&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '低保救助信息',
            reqUrl: 'http://172.23.31.13/gateway/api/001008006007008/dataSharing/lowRescueInfo.htm',
            params: `requestTime=${time}&mhzsfz=${cardId}&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '低保边缘信息',
            reqUrl: 'http://172.23.31.13/gateway/api/001008006007008/dataSharing/lowMarginInfo.htm',
            params: `requestTime=${time}&mhzsfz=${cardId}&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '个人社保养老待遇发放情况',
            reqUrl: 'http://172.23.31.13/gateway/api/001008006007011/dataSharing/UF8794a3UpLfKoP0.htm',
            params: `requestTime=${time}&idcard=${cardId}&name=${name}&areaAK=ZjE0LTkxMDQtMmZjYzgxNzQ3Njhi&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '个人社保信息查询',
            reqUrl: 'http://172.23.31.13/gateway/api/001008006007011/dataSharing/1defS0Vb1lLiD9de.htm',
            params: `requestTime=${time}&idcard=${cardId}&name=${name}&areaAK=NzIxLWFkN2ItZWY5YThhODJiMDgz&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '户籍查询',
            reqUrl: 'http://172.23.31.13/gateway/api/001008006007007/dataSharing/allHouseholdRegistrationInfo.htm',
            params: `requestTime=${time}&GMSFZHM=${cardId}&sign=${sign}&appKey=${appkey}`,
        }, {
            api: '绍兴市火化信息',
            reqUrl: 'http://172.23.31.13:80/gateway/api/001104/dataSharing/sxCremationInfoNew.htm',
            params: `requestTime=${time}&SSFZ=${cardId}&sign=${sign}&appKey=${appkey}`,
        }];
    //var params = `requestTime=${time}&sfzmhm=${cardId}&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&cardId=${cardId}&sign=${sign}&name=${name}&appKey=${appkey}`;
    //var params = `requestTime=${time}&QLRZJH=${cardId}&QLRMC=${name}&dispatchCode=${cardId.substring(0,6)}&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&uniscId=${cardId}&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&mhzsfz=${cardId}&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&mhzsfz=${cardId}&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&name=${name}&idcard=${cardId}&areaAK=NzIxLWFkN2ItZWY5YThhODJiMDgz&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&idcard=${cardId}&name=${name}&areaAK=NzIxLWFkN2ItZWY5YThhODJiMDgz&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&GMSFZHM=${cardId}&sign=${sign}&appKey=${appkey}`;
    //var params = `requestTime=${time}&SSFZ=${cardId}&sign=${sign}&appKey=${appkey}`;
    let promiseArr = [];
    for (var i = 0; i < apiArr.length; i++) {
        var index = apiArr[i];
        //获取企业登记信息的 index = 3
        // if (index == 3 && uniscId == '') { continue; }
        let options = {
            'method': 'POST',
            'url': `${arr[index].reqUrl}?${arr[index].params}`,
            'headers': {},
        };
        //console.log('url',`${arr[index].reqUrl}?${arr[index].params}`);
        promiseArr.push(
            new Promise((resolve, reject) => {
                request(options, (error, response) => {
                    if (error) { console.log('数据请求出现错误'); reject('出现错误'); throw new Error(error); }
                    var res = JSON.parse(response.body);
                    //console.log(res);
                    //res.datas 如果是字符需要转换为对象
                    if (typeof res.datas == 'string') {
                        res.datas = JSON.parse(res.datas);
                    }
                    resolve(res)
                });
            })
        )
    }
    return Promise.all(promiseArr).then(res => {
        var result = [];
        console.log('total',res);
        for (var k = 0; k < apiArr.length; k++) {
            var item = res[k];
            // console.log(item)
            if (item.code == '00' && item.datas != null) {
                var singleData = '';
                switch (apiArr[k]) {
                    case 0:
                        singleData = item.datas[0];
                        result.push({
                            cLLX: singleData.cLLX,
                            cLPP1: singleData.cLPP1,
                            hPHM: singleData.hPHM,
                            sYXZ: singleData.sYXZ,
                            index: apiArr[k]
                        });
                        break;
                    case 1:
                        singleData = item.datas[0];
                        result.push({
                            companyName:singleData.companyName,
                            index: apiArr[k]
                        });
                        break;
                    case 2:
                        singleData = item.datas[0].jgnr;
                        var fc = [];
                        for(var m= 0;m<singleData.fc.length;m++){
                            fc.push({
                                bdcqzh:singleData.fc[m].bdcqzh,
                                mj:singleData.fc[m].mj,
                                zl:singleData.fc[m].zl
                            })
                        }
                        result.push({
                            fc:fc,
                            index: apiArr[k]
                        });
                        break;
                    case 3:
                        singleData = item.datas;
                        console.log('1013',item);
                        var company = [];
                        for(var a= 0;a<singleData.length;a++){
                            company.push(`${singleData[a].qYMC}`)
                        }
                        result.push({
                            companys:company.toString(),
                            index: apiArr[k]
                        });
                        break;
                    case 4:
                        singleData = item.datas[0];
                        result.push({
                            mzjzje:singleData.mzjzje,
                            mzpyy:singleData.mzpyy,
                            index: apiArr[k]
                        });
                        break;
                    case 5:
                        singleData = item.datas[0];
                        result.push({
                            mzpyy:singleData.mzpyy,
                            sam00:singleData.sam00,
                            index: apiArr[k]
                        });
                        break;
                    case 6:
                        singleData = item.datas.singleData;
                        result.push(
                            item.datas.success == true ?
                                {
                                    dyffzt: singleData.dyffzt,
                                    dylx: singleData.dylx,
                                    dysp: singleData.dysp,
                                    jfmax: singleData.jfmax,
                                    jfmin: singleData.jfmin,
                                    index: apiArr[k]
                                }
                                : null);
                        break;
                    case 7:
                        singleData = item.datas.singleData;
                        result.push(
                            item.datas.success == true ?
                                {
                                    aab004: singleData.aab004,
                                    gszt: singleData.gszt,
                                    jfmax: singleData.jfmax,
                                    jfmin: singleData.jfmin,
                                    index: apiArr[k]
                                }
                                : null);
                        break;
                    case 8:
                        singleData = item.datas[0];
                        var person = [];
                        for(var n= 0;n<singleData.jTCY.length;n++){
                            person.push(`${singleData.jTCY[n].xM}(${singleData.jTCY[n].yHZGX})`)
                        }
                        result.push({
                            persons:person.toString(),
                            index: apiArr[k]
                        });
                        break;
                        case 9:
                            singleData = item.datas;
                            result.push({die:singleData});
                            break;
                    default:
                        result.push(null);
                        break;
                }
            } else {
                //请求失败或未查询到数据
                result.push(null);
                continue;
            }
        }
        return {
            name: name,
            cardId: cardId,
            apiArr: apiArr,
            result: result
        };

    });
}

//获取最新的请求秘钥
async function getSecrect(method) {
    var options = {
        'method': 'POST',
        'url': `https://env-web-16c0e3-1258099036.ap-shanghai.service.tcloudbase.com/secrect?method=${method}`,
        'headers': {
            'Content-Type': 'application/json'
        }

    };
    const promise = new Promise((resolve, reject) => {
        request(options, (error, response) => {
            if (error) { console.log('获取最新的请求秘钥'); reject('出现错误'); throw new Error(error); }
            var res = JSON.parse(response.body);
            //console.log('101',res);
            if (res.code == 2) {
                //使用bysec刷新秘钥
                resolve(refresh('bysec', res.data.refreshSecret));
                //resolve(refresh('bykey',appsec));
            } else if (res.code == 3) {
                //使用bykey刷新秘钥
                resolve(refresh('bykey', appsec));
            } else {
                //请求秘钥有效
                resolve(res.data.requestSecret);
            }
        });
    });
    return promise;
}
//刷新秘钥
async function refresh(method, refsec) {
    var newTime = new Date()
    var time = newTime.getTime();
    var str = appkey + refsec + time;
    var sign = md5(str);
    var url = method == 'bysec' ? 'http://172.23.31.13:80/gateway/app/refreshTokenBySec.htm' : 'http://172.23.31.13:80/gateway/app/refreshTokenByKey.htm';
    var param = `requestTime=${time}&sign=${sign}&appKey=${appkey}`;
    var options = {
        'method': 'POST',
        'url': `${url}?${param}`,
        'headers': {
            'Content-Type': 'application/json'
        }
    }
    const promise = new Promise((resolve, reject) => {
        request(options, (error, response) => {
            if (error) { console.log('刷新秘钥'); reject('出现错误'); throw new Error(error); }
            //获取到新的请求秘钥
            //秘钥持久化.datas.requestSecret
            //console.log('新请求秘钥',JSON.parse(response.body));
            saveSecret('savesecret', JSON.stringify(JSON.parse(response.body).datas))
            //console.log(JSON.stringify(JSON.parse(response.body).datas));
            resolve(JSON.parse(response.body).datas.requestSecret);
        });
    });
    return promise;
}
//持久化秘钥
async function saveSecret(method, body) {
    var options = {
        'method': 'POST',
        'url': `https://env-web-16c0e3-1258099036.ap-shanghai.service.tcloudbase.com/secrect?method=${method}&data=${body}`,
        'headers': {
            'Content-Type': 'application/json'
        }

    };
    request(options, function (error, response) {
        if (error) throw new Error(error);
        var res = JSON.parse(response.body);
        if (res.updated) {
            //更新完成
            console.log('秘钥更新 updated：', res.updated);
        } else {
            //出现错误
        }
        //
    });
}


//1.输入数据，点击查询，触发函数，将数据传入外部js文件中
//2.进行请求,等待大数据返回数据
//3.大数据返回数据预处理
//4.返回至"调用文件"
//5.赋值参数

export default main
